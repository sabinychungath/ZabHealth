import React, { useState } from "react";
import { 
  ChakraProvider, 
  Box,
  Container,
  Heading,
  Text,
  VStack,
  Grid,
  GridItem,
  Button,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
} from "@chakra-ui/react";
import { FiMic, FiUpload, FiFileText, FiFile } from "react-icons/fi";
import "./style.css";

import AudioRecorder from "./AudioRecorder";
import FileUpload from "./FileUpload";
import Summary from "./Summary";
import ReferenceLetter from "./ReferenceLetter";

const App = () => {
  const [transcribedText, setTranscribedText] = useState("");
  const [showSummary, setShowSummary] = useState(false);
  const [showReference, setShowReference] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [modalContent, setModalContent] = useState(null);

  const handleTranscribedText = (text) => {
    setTranscribedText(text);
  };

  const handleTranscribingState = (state) => {
    setIsTranscribing(state);
  };

  const handleViewSummary = () => {
    setShowSummary(true);
    setShowReference(false);
    setModalContent(<Summary text={transcribedText} />);
    onOpen();
  };

  const handleViewReference = () => {
    setShowReference(true);
    setShowSummary(false);
    setModalContent(<ReferenceLetter text={transcribedText} />);
    onOpen();
  };

  return (
    <ChakraProvider>
      <Box className="app-container">
        <VStack spacing={6} align="stretch" mb={8}>
          <Heading 
            as="h1" 
            size="2xl" 
            color="black" 
            textAlign="center"
            fontWeight="bold"
            textShadow="0 2px 10px rgba(0,0,0,0.2)"
          >
            AI Health Assistant
          </Heading>
          <Text 
            color="black" 
            textAlign="center" 
            fontSize="lg"
            maxW="800px"
            mx="auto"
          >
            Record or Upload Voices, Generate Summaries and Referral Letters
          </Text>
        </VStack>

        <Container maxW="container.xl" p={4}>
          <Grid templateColumns="repeat(2, 1fr)" gap={6}>
            <GridItem w="100%">
              <Box 
                bg="whiteAlpha.200" 
                p={6} 
                borderRadius="xl" 
                backdropFilter="blur(10px)"
              >
                <Heading size="md" color="black" mb={4}>Voice Recording</Heading>
                <AudioRecorder 
                  onTranscribe={handleTranscribedText} 
                  onTranscribing={handleTranscribingState}
                />
              </Box>
            </GridItem>

            <GridItem w="100%">
              <Box 
                bg="whiteAlpha.200" 
                p={6} 
                borderRadius="xl" 
                backdropFilter="blur(10px)"
              >
                <Heading size="md" color="black" mb={4}>File Upload</Heading>
                <FileUpload onTranscribe={handleTranscribedText} />
              </Box>
            </GridItem>
          </Grid>

          {transcribedText && (
            <Box mt={6}>
              <Heading size="md" color="black" mb={4}>Transcribed Text</Heading>
              <Box 
                bg="whiteAlpha.200" 
                p={4} 
                borderRadius="xl" 
                color="black"
                maxH="200px"
                overflowY="auto"
              >
                {transcribedText}
              </Box>
            </Box>
          )}

          <Grid templateColumns="repeat(2, 1fr)" gap={6} mt={6}>
            <Button
              leftIcon={<FiFileText />}
              colorScheme="purple"
              size="lg"
              onClick={handleViewSummary}
              isDisabled={!transcribedText || isTranscribing}
              //isDisabled={!transcribedText}
            >
              Generate Summary
            </Button>
            <Button
              leftIcon={<FiFile />}
              colorScheme="purple"
              size="lg"
              onClick={handleViewReference}
              isDisabled={!transcribedText || isTranscribing}
            >
              Generate Referral Letter
            </Button>
          </Grid>
        </Container>

        <Modal isOpen={isOpen} onClose={onClose} size="xl">
          <ModalOverlay backdropFilter="blur(10px)" />
          <ModalContent>
            <ModalHeader>
              {showSummary ? "Content Summary" : "Referral Letter"}
            </ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>
              {modalContent}
            </ModalBody>
          </ModalContent>
        </Modal>
      </Box>
    </ChakraProvider>
  );
};

export default App;