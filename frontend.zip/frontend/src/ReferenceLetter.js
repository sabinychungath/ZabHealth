import React, { useRef } from 'react';
import { 
  Box, 
  Heading, 
  Text, 
  VStack, 
  Button, 
  Icon,
  HStack,
  useToast
} from '@chakra-ui/react';
import { FiDownload, FiCopy, FiPrinter } from 'react-icons/fi';
import { useReactToPrint } from 'react-to-print';

const ReferenceLetter = ({ text }) => {
  const componentRef = useRef();
  const toast = useToast();

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    onAfterPrint: () => toast({
      title: "Print successful",
      status: "success",
      duration: 2000,
    })
  });

  // This would typically be generated based on the transcribed text
  const letterContent = `
Sorry for the inconvinience. 
The page is under development.
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(letterContent)
      .then(() => {
        toast({
          title: "Copied to clipboard",
          status: "success",
          duration: 2000,
        });
      })
      .catch(err => console.error('Failed to copy: ', err));
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([letterContent], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = 'reference_letter.txt';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Letter downloaded successfully",
      status: "success",
      duration: 2000,
    });
  };

  return (
    <VStack spacing={4} align="stretch" ref={componentRef}>
      <Box p={4}>
        <Heading size="md" color="gray.800" mb={4}>Referral Letter</Heading>
        
        <Box 
          bg="white" 
          p={4} 
          borderRadius="md" 
          border="1px" 
          borderColor="gray.200"
          whiteSpace="pre-line"
          mb={4}
        >
          <Text color="gray.700">{letterContent}</Text>
        </Box>
        
        <HStack spacing={4} justifyContent="flex-end">
          <Button 
            leftIcon={<Icon as={FiCopy} />} 
            colorScheme="purple" 
            variant="outline"
            onClick={handleCopy}
          >
            Copy
          </Button>
          <Button 
            leftIcon={<Icon as={FiDownload} />} 
            colorScheme="purple" 
            variant="outline"
            onClick={handleDownload}
          >
            Download
          </Button>
          <Button 
            leftIcon={<Icon as={FiPrinter} />} 
            colorScheme="purple"
            onClick={handlePrint}
          >
            Print
          </Button>
        </HStack>
      </Box>
    </VStack>
  );
};

export default ReferenceLetter;