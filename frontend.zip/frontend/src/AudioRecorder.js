import React, { useRef, useState, useEffect } from 'react';
import { 
  Box, 
  Button, 
  HStack, 
  Text, 
  VStack, 
  Icon,
  Progress 
} from '@chakra-ui/react';
import { FiMic, FiStopCircle, FiPlay, FiPause } from 'react-icons/fi';
import WaveSurfer from 'wavesurfer.js';

const AudioRecorder = ({ onTranscribe, onTranscribing }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [currentTranscription, setCurrentTranscription] = useState("");
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const waveformRef = useRef(null);
  const wavesurferRef = useRef(null);

  useEffect(() => {
    if (recordedAudio && waveformRef.current) {
      if (wavesurferRef.current) {
        wavesurferRef.current.destroy();
      }
      
      wavesurferRef.current = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: 'rgba(0, 0, 0, 0.5)',
        progressColor: 'rgba(0, 0, 0, 0.8)',
        cursorColor: '#000',
        barWidth: 2,
        barRadius: 3,
        cursorWidth: 1,
        height: 80,
        barGap: 3
      });
      
      wavesurferRef.current.load(recordedAudio);
      
      wavesurferRef.current.on('finish', () => {
        setIsPlaying(false);
      });
    }
    
    return () => {
      if (wavesurferRef.current) {
        wavesurferRef.current.destroy();
      }
    };
  }, [recordedAudio]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm'  // Use webm format which is widely supported
      });
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };
      
      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setRecordedAudio(audioUrl);
        transcribeAudio(audioBlob);
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const togglePlayback = () => {
    if (wavesurferRef.current) {
      if (isPlaying) {
        wavesurferRef.current.pause();
      } else {
        wavesurferRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const transcribeAudio = async (audioBlob) => {
    setTranscribing(true);
    onTranscribing(true);  // Notify parent component
    setCurrentTranscription("");
    const formData = new FormData();
    formData.append("file", audioBlob, "recording.webm");

    try {
      console.log("Sending transcription request to backend...");
      const response = await fetch("http://localhost:5002/transcribe", {
        method: "POST",
        body: formData,
        mode: 'cors',
        headers: {
          'Accept': 'application/json',
        },
      });

      console.log("Response status:", response.status);
      const responseText = await response.text();
      console.log("Raw response:", responseText);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}, response: ${responseText}`);
      }

      const data = JSON.parse(responseText);
      if (data.transcribed_text) {
        console.log("Transcription successful:", data.transcribed_text);
        setCurrentTranscription(data.transcribed_text);
        onTranscribe(data.transcribed_text);
      } else if (data.error) {
        console.error("Error in transcription:", data.error);
        setCurrentTranscription(`Error: ${data.error}`);
      } else {
        console.error("Error in transcription:", data);
        setCurrentTranscription("Error in transcription. Please try again.");
      }
    } catch (error) {
      console.error("Transcription request failed:", error);
      if (error.message === "Failed to fetch") {
        setCurrentTranscription("Could not connect to the server. Please make sure the backend is running.");
      } else {
        setCurrentTranscription(`Transcription failed: ${error.message}`);
      }
    }

    setTranscribing(false);
    onTranscribing(false);  // Notify parent component
  };

  return (
    <VStack spacing={4} width="100%">
      <HStack spacing={4} width="100%" justifyContent="center">
        {!isRecording ? (
          <Button
            leftIcon={<Icon as={FiMic} />}
            colorScheme="red"
            variant="solid"
            onClick={startRecording}
            size="lg"
            borderRadius="full"
          >
            Start Recording
          </Button>
        ) : (
          <Button
            leftIcon={<Icon as={FiStopCircle} />}
            colorScheme="red"
            variant="solid"
            onClick={stopRecording}
            size="lg"
            borderRadius="full"
          >
            Stop Recording
          </Button>
        )}
      </HStack>

      {isRecording && (
        <Text color="black" fontStyle="italic">
          Recording in progress... Speak now
        </Text>
      )}

      {recordedAudio && (
        <Box width="100%">
          <Box className="waveform" ref={waveformRef} />
          
          <HStack justifyContent="center" mt={2}>
            <Button
              leftIcon={<Icon as={isPlaying ? FiPause : FiPlay} />}
              colorScheme="purple"
              variant="solid"
              onClick={togglePlayback}
              size="md"
              borderRadius="full"
            >
              {isPlaying ? 'Pause' : 'Play'}
            </Button>
          </HStack>
        </Box>
      )}

      {transcribing && (
        <Box width="100%">
          <Text color="black" mb={2}>Transcribing audio...</Text>
          <Progress size="xs" isIndeterminate colorScheme="purple" />
        </Box>
      )}
    </VStack>
  );
};

export default AudioRecorder;