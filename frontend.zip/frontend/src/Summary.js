import React, { useRef, useState, useEffect } from 'react';
import { 
  Box, 
  Heading, 
  Text, 
  VStack, 
  Badge, 
  Button,
  HStack,
  useToast,
  Spinner,
  List,
  ListItem,
  ListIcon
} from '@chakra-ui/react';
import { FiDownload, FiPrinter, FiCheck } from 'react-icons/fi';
import { useReactToPrint } from 'react-to-print';

const Summary = ({ text }) => {
  const componentRef = useRef();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    generateSummary();
  }, [text]);

  const generateSummary = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:5002/generate_summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate summary');
      }

      if (!data || (!data.keyPoints && !data.diagnosis && !data.recommendations && !data.followUp)) {
        throw new Error('Invalid summary data received');
      }

      setSummary(data);
    } catch (err) {
      console.error('Summary generation error:', err);
      setError(err.message || 'Failed to generate summary. Please try again.');
      
      // Show error toast
      toast({
        title: "Error generating summary",
        description: err.message || "Please check your Azure OpenAI configuration and try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    onAfterPrint: () => toast({
      title: "Print successful",
      status: "success",
      duration: 2000,
    })
  });

  const handleSave = () => {
    const element = document.createElement('a');
    const file = new Blob([JSON.stringify(summary, null, 2)], {type: 'application/json'});
    element.href = URL.createObjectURL(file);
    element.download = 'medical_summary.json';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Summary saved successfully",
      status: "success",
      duration: 2000,
    });
  };

  if (loading) {
    return (
      <Box textAlign="center" py={10}>
        <Spinner size="xl" color="purple.500" />
        <Text mt={4} color="gray.600">Generating summary...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" py={10}>
        <Text color="red.500">{error}</Text>
        <Button mt={4} colorScheme="purple" onClick={generateSummary}>
          Try Again
        </Button>
      </Box>
    );
  }

  return (
    <VStack spacing={4} align="stretch" ref={componentRef}>
      <Box className="summary-content" p={4}>
        <Heading size="md" color="gray.800" mb={4}>Medical Summary</Heading>
        
        {summary && (
          <>
            <Box mb={6}>
              <Text fontWeight="bold" color="gray.700" mb={2}>Key Points</Text>
              <List spacing={3}>
                {summary.keyPoints.map((point, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={FiCheck} color="green.500" />
                    <Text color="gray.700">{point}</Text>
                  </ListItem>
                ))}
              </List>
            </Box>

            {summary.diagnosis && (
              <Box mb={6}>
                <Text fontWeight="bold" color="gray.700" mb={2}>Diagnosis</Text>
                <Text color="gray.700">{summary.diagnosis}</Text>
              </Box>
            )}

            {summary.recommendations && summary.recommendations.length > 0 && (
              <Box mb={6}>
                <Text fontWeight="bold" color="gray.700" mb={2}>Recommendations</Text>
                <List spacing={2}>
                  {summary.recommendations.map((rec, index) => (
                    <ListItem key={index} display="flex" alignItems="center">
                      <ListIcon as={FiCheck} color="purple.500" />
                      <Text color="gray.700">{rec}</Text>
                    </ListItem>
                  ))}
                </List>
              </Box>
            )}

            {summary.followUp && (
              <Box mb={6}>
                <Text fontWeight="bold" color="gray.700" mb={2}>Follow-up</Text>
                <Text color="gray.700">{summary.followUp}</Text>
              </Box>
            )}
          </>
        )}
      </Box>

      <HStack spacing={4} justifyContent="flex-end" mt={4}>
        <Button
          leftIcon={<FiDownload />}
          colorScheme="purple"
          variant="outline"
          onClick={handleSave}
        >
          Save
        </Button>
        <Button
          leftIcon={<FiPrinter />}
          colorScheme="purple"
          onClick={handlePrint}
        >
          Print
        </Button>
      </HStack>
    </VStack>
  );
};

export default Summary;