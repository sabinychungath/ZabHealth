import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Box, 
  Text, 
  VStack, 
  Image, 
  Flex, 
  Icon, 
  Progress,
  Button 
} from '@chakra-ui/react';
import { FiUpload, FiFile, FiFileText } from 'react-icons/fi';

const FileUpload = ({ onTranscribe }) => {
  const [files, setFiles] = useState([]);
  const [transcribing, setTranscribing] = useState(false);

  const onDrop = useCallback(acceptedFiles => {
    setFiles(acceptedFiles);
    handleFileTranscription(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'audio/*': [],
      'text/plain': [],
      'application/pdf': [],
      'application/msword': [],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': []
    }
  });

  const handleFileTranscription = async (file) => {
    setTranscribing(true);
    
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("http://healthcare-appcopy-backend-1:5000/transcribe", {
        method: "POST",
        body: formData,
        headers: {
          "Authorization": "Bearer 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"
        }
      });

      const data = await response.json();
      if (data.transcribed_text) {
        onTranscribe(data.transcribed_text);
      } else {
        console.error("Error in transcription:", data);
      }
    } catch (error) {
      console.error("Transcription request failed:", error);
    }

    setTranscribing(false);
  };

  return (
    <VStack spacing={4} width="100%">
      <Box 
        {...getRootProps()} 
        className="dropzone"
        width="100%"
        color="black"
      >
        <input {...getInputProps()} />
        <VStack spacing={2}>
          <Icon as={FiUpload} w={10} h={10} />
          {isDragActive ? (
            <Text>Drop the files here...</Text>
          ) : (
            <Text>Drag & drop files here, or click to select files</Text>
          )}
          <Text fontSize="sm">
            Supports audio files and documents
          </Text>
        </VStack>
      </Box>

      {files.length > 0 && (
        <VStack width="100%" spacing={3} align="stretch">
          <Text fontWeight="bold" color="black">Uploaded File:</Text>
          {files.map((file, index) => (
            <Flex 
              key={index} 
              className="file-preview"
              alignItems="center"
            >
              <Icon 
                as={file.type.startsWith('audio/') ? FiFileText : FiFile} 
                w={10} 
                h={10} 
                color="black" 
              />
              <Box ml={4}>
                <Text color="black" fontWeight="medium">{file.name}</Text>
                <Text color="black" fontSize="sm">
                  {(file.size / 1024).toFixed(2)} KB
                </Text>
              </Box>
            </Flex>
          ))}
        </VStack>
      )}

      {transcribing && (
        <Box width="100%">
          <Text color="black" mb={2}>Processing file...</Text>
          <Progress size="xs" isIndeterminate colorScheme="purple" />
        </Box>
      )}
    </VStack>
  );
};

export default FileUpload;